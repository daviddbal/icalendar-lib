package net.balsoftware.icalendar;

/**
 * Creates VElements from strings and Iterator<String>
 * 
 * @author David Bal
 *
 */
public abstract class SimpleVElementFactory extends VElementBase
{

	public static VElement newElement(String string)
	{
//		clazz = 
//		NO_ARG_CONSTRUCTORS.get(clazz);
		// TODO Auto-generated method stub
		throw new RuntimeException("not implemented");
	}

}
