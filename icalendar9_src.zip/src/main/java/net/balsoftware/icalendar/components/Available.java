package net.balsoftware.icalendar.components;

public class Available
{
    // TODO
    public Available()
    {
        throw new RuntimeException("Not implemented");
    }
}
