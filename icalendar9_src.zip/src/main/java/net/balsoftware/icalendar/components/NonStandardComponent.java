package net.balsoftware.icalendar.components;

public abstract class NonStandardComponent<T> extends VLocatable<T> implements VDateTimeEnd<T>,
VDescribable2<T>, VRepeatable<T>
{

    NonStandardComponent()
    {
        throw new RuntimeException("not implemented");
        // TODO - FINISH THIS
    }
}
