package net.balsoftware.icalendar.components;

public class VAvailability
{
    // TODO
    public VAvailability()
    {
        throw new RuntimeException("Not implemented");
    }
}
