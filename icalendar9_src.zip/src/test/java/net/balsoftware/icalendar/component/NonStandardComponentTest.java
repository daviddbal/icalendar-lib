package net.balsoftware.icalendar.component;

import org.junit.Test;

public class NonStandardComponentTest
{        
    @Test
    public void canBuildNonStandardComponent()
    {
        // TODO
    }
}
